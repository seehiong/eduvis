"""
EduVis Core — LLM Prompt Vocabulary Generator.

Produces a complete, self-contained vocabulary block that describes the EduVis
schema to an LLM. Inject into the system prompt so the model can write valid
EduVis lesson specs without needing to infer structure from examples alone.

Usage:
    from eduvis.core.prompt import format_prompt_docs
    system_prompt = f"...\n\n{format_prompt_docs(['math'])}"
"""

from __future__ import annotations

from .registry import ElementRegistry
from .schemas.placement import (
    VALID_PHASES, VALID_MEMORY_ROLES, VALID_DIFFICULTY,
    VALID_PURPOSES, VALID_LAYOUT_ZONES, VALID_VISUAL_WEIGHTS,
    VALID_ASSESSMENT_OBJECTIVES,
)
from .schemas.actions import VALID_CONCEPTUAL, VALID_PROCEDURAL
from .schemas.relationships import VALID_TYPES as VALID_REL_TYPES
from .schemas.progression import VALID_PHASES as PROG_PHASES
from .constants import SCHEMA_VERSION


def format_prompt_docs(subjects: list[str]) -> str:
    """
    Return the complete EduVis vocabulary for an LLM system prompt.

    subjects: list of subject tags to include, e.g. ["math"] or ["math", "science"].
              "*" (all subjects) is always included regardless of this argument.

    The returned string covers:
      1. Lesson skeleton  — top-level YAML structure
      2. Progression      — named patterns, pedagogy flags, phase sequence
      3. Placement        — lesson phases, memory roles, difficulty, purpose
      4. Actions          — conceptual and procedural action vocabularies
      5. Relationships    — relationship types and syntax
      6. Elements         — all element types and their field schemas
    """
    parts = [
        _lesson_skeleton(),
        _progression_docs(),
        _placement_docs(),
        _actions_docs(),
        _relationships_docs(),
        _elements_docs(subjects),
    ]
    return "\n\n".join(parts)


# ── Section builders ──────────────────────────────────────────────────────────

def _lesson_skeleton() -> str:
    return """\
## EduVis Lesson Structure

Every lesson YAML has five top-level keys: schema_version, curriculum, lesson, progression, content.

```yaml
schema_version: "VERSION"

curriculum:
  code: string            # curriculum code e.g. "SEC-math-2027"
  topic: string           # topic code e.g. "N1.6"
  concept: string         # optional target concept name
  requires:               # optional list of prerequisite concept names
    - string
  supports:               # optional list of supporting concept names
    - string
  learning_outcomes:      # optional list of target learning outcomes
    - string
  assessment_targets:     # optional list of assessment targets / objectives
    - string

lesson:
  title: string           # human-readable lesson title
  concepts:               # optional list of target concepts
    - string

progression:
  pattern: confidence_ladder | direct_instruction | flipped_recall
  pedagogy:
    confidence_first: true | false
    explain_why: true | false
    no_skipped_steps: true | false
  phases:
    - phase: <lesson_phase>
      purpose: <purpose>       # optional, use in explain phase
      difficulty: <difficulty> # optional, use in practice phases
      count: <integer>         # optional, number of elements in this phase

content:
  - id: string             # unique identifier within the lesson
    type: <element_type>   # see Element Types below
    concepts:              # optional list of concepts taught by this element
      - string
    placement:
      lesson_phase: <lesson_phase>
      memory_role: <memory_role>
      difficulty: <difficulty>   # optional
      purpose: <purpose>         # optional
      visual_weight: primary | supporting  # optional
      layout_zone: center | left | right | full | bottom  # optional
      pedagogical_intent:       # optional, guides generation and support
        intent: confidence_building | reduce_anxiety | curiosity | productive_struggle
        scaffolding_level: high | medium | low
    actions:               # optional
      conceptual:
        - <action>: <target>
      procedural:
        - <action>
    relationships:         # optional
      <rel_type>:
        - <other_element_id>
    <element-specific fields...>
```""".replace("VERSION", SCHEMA_VERSION)


def _progression_docs() -> str:
    phases_list = " | ".join(sorted(PROG_PHASES))
    return f"""\
## Progression

### Named Patterns
  confidence_ladder   Hook -> Explore -> Explain -> Guided -> Starter Practice -> Routine Practice -> Challenge -> Recall
  direct_instruction  Hook -> Explain -> Guided -> Independent Practice -> Recall
  flipped_recall      Recall -> Hook -> Explore -> Explain -> Practice

### Pedagogy Flags
  confidence_first    starter-difficulty elements must appear before routine in content order
  explain_why         a conceptual_model element must precede any procedure element in the explain phase
  no_skipped_steps    every guided_practice element must declare at least one action

### Phase Sequence
Phases in the phases list define the intended lesson flow and the expected count of elements per phase.
Valid phase names: {phases_list}"""


def _placement_docs() -> str:
    phases = " | ".join(sorted(VALID_PHASES))
    roles = " | ".join(sorted(VALID_MEMORY_ROLES))
    difficulties = " | ".join(sorted(VALID_DIFFICULTY))
    purposes = " | ".join(sorted(VALID_PURPOSES))
    zones = " | ".join(sorted(VALID_LAYOUT_ZONES))
    weights = " | ".join(sorted(VALID_VISUAL_WEIGHTS))
    objectives = " | ".join(sorted(VALID_ASSESSMENT_OBJECTIVES))

    return f"""\
## Placement

Every content element MUST have a placement block with lesson_phase and memory_role.

### lesson_phase (required)
{phases}

  hook                 Concrete scenario before the concept is named
  explore              Student observes a pattern before the rule is stated
  explain              Rule or concept revealed — use purpose: conceptual_model before procedure
  guided_practice      Instructor walks through a worked example; must have at least one action
  independent_practice Student applies the concept; set difficulty accordingly
  challenge            Stretch problem beyond routine application
  reflect              Student articulates what they learned
  recall               Student retrieves without re-reading; builds long-term memory

### memory_role (required)
{roles}

  anchor               The one element the student should remember weeks later
  example              Demonstrates the concept in a specific case
  practice             Used during in-lesson application
  misconception_fix    Corrects a specific common error
  retrieval            Shown during a recall exercise
  review               Appears in a future lesson as spaced repetition

### difficulty (optional — use in independent_practice and challenge phases)
{difficulties}

  starter              Intentionally easy — builds confidence before the concept feels hard
  routine              Typical exam-style problems
  challenge            Harder realistic problems or stretch questions

### purpose (optional — use in explain phase)
{purposes}

  conceptual_model     Builds intuition before the rule is stated (always place before procedure)
  procedure            States the rule or worked algorithm explicitly
  worked_example       Shows a complete solved example
  comparison           Places two cases side-by-side
  summary              Closing recap of the lesson

### assessment_objective (optional — use on multiple_choice and short_answer elements)
{objectives}

  procedural_fluency       Student executes a practiced algorithm or procedure correctly
  conceptual_understanding Student demonstrates grasp of the underlying idea, not just the steps
  application              Student applies the concept to an unfamiliar or real-world context
  reasoning                Student explains, justifies, or proves — goes beyond recall

IMPORTANT: assessment_objective is optional and only meaningful on assessment element types
(multiple_choice, short_answer). It enables curriculum-level analysis of what each question tests,
preventing every generated curriculum from inventing its own labels.

### layout_zone (optional)
{zones}

### visual_weight (optional)
{weights}

### pedagogical_intent (optional)
Pedagogical intent metadata to guide content generation and support. Contains fields:
  intent               confidence_building | reduce_anxiety | curiosity | productive_struggle
  scaffolding_level    high | medium | low"""


def _actions_docs() -> str:
    conceptual = " | ".join(sorted(VALID_CONCEPTUAL))
    procedural = " | ".join(sorted(VALID_PROCEDURAL))
    return f"""\
## Actions

Actions describe what the element asks the student to do. Split into two groups.

```yaml
actions:
  conceptual:          # cognitive intent — what the student thinks or notices
    - compare: [-3, 5]                     # draw attention to a difference
    - predict: unknown                     # student supplies a missing value
    - identify: misconception              # student spots an error before it is revealed
    - retrieve: concept-name               # student recalls from memory
    - apply: concept-name                  # student applies a rule to a new case
  procedural:          # step-by-step mathematical transformations (no_skipped_steps)
    - substitute: {{from: x, to: 3}}        # replace a variable — one explicit step
    - simplify                             # reduce an expression — one explicit step
    - calculate                            # perform arithmetic — one explicit step
    - round: {{decimal_places: 2}}          # round to precision — one explicit step
```

Valid conceptual actions: {conceptual}
Valid procedural actions: {procedural}

IMPORTANT: Actions are not animation instructions. "compare" means this element
exists to make a comparison salient — the renderer decides how to show it.

IMPORTANT: When no_skipped_steps is true, every guided_practice element must
declare at least one action. Use procedural for computation steps, conceptual
for reasoning steps."""


def _relationships_docs() -> str:
    rel_types = " | ".join(sorted(VALID_REL_TYPES))
    return f"""\
## Relationships

Relationships describe how elements connect within the lesson. They enable
coherence checking and AI lesson assembly.

```yaml
relationships:
  anchors:
    - hook_temperature      # this element is the concrete anchor for the concept
  contradicts:
    - misconception_panel   # this element corrects the previous one
  precedes:
    - practice_starter_1    # this element scaffolds the next element
  reinforces:
    - explain_concept        # this element recalls an earlier anchor
  parallels:
    - abstract_version       # two elements show the same concept at different abstraction levels
  remediation_for:
    - check_question_1      # this element is presented conditionally when a check fails
```

Valid relationship types: {rel_types}

Each value is a list of element id strings. Referenced IDs must exist in the
same lesson's content list.

### Remediation and Hints: Inline vs. Decoupled Branching
When specifying help and hints for questions, there are two distinct design patterns:
1. **Inline worked hints (solution_steps field)**: Defined inside multiple_choice or short_answer elements via the solution_steps array. These are short, immediate, inline steps shown inside the same question slide (e.g. for correct answers or when showing inline hints).
2. **Decoupled remediation routing (remediation_block & remediation_for relationship)**: Renders a dedicated remediation_block element on a separate slide containing review, remember, and solve blocks. This slide declares relationships.remediation_for pointing back to the question. It acts as a full-screen pedagogical intervention when a check is failed.
"""


def _elements_docs(subjects: list[str]) -> str:
    element_vocab = ElementRegistry.format_prompt_docs(subjects)
    subject_label = ", ".join(subjects) if subjects else "all"
    return f"""\
## Element Types (subjects: {subject_label})

Each content element requires a `type` field. The available types and their
required/optional fields are listed below.

```
{element_vocab}
```

IMPORTANT: Only use fields listed above for each element type. Do not invent fields."""
